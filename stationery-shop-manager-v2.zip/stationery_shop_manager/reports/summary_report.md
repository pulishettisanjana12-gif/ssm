# 📊 Stationery Shop Manager - Executive Summary Report
**Generated On:** 2026-11-24 09:18:14

## 📈 Key Performance Indicators (KPIs)
- **Total Catalog Items:** 35
- **Total Units in Stock:** 1299 units
- **Total Inventory Valuation:** $6,945.31
- **Total Revenue Generated:** $220.22
- **Total Sales Transactions:** 8
- **Total Units Sold:** 28

## ⚠️ Inventory Health & Threshold Breakdown
- ✅ **In Stock:** 22
- 🟡 **Low Stock Alert:** 4
- 🟠 **Reorder Needed (Urgent):** 5
- 🔴 **Out of Stock:** 4

## 📁 Inventory Valuation by Category
| Category | Unique Items | Units in Stock | Category Valuation ($) |
| :--- | :---: | :---: | :---: |
| Paper & Envelopes | 5 | 337 | $1,896.63 |
| Writing Instruments | 5 | 360 | $1,053.90 |
| Markers & Highlighters | 4 | 104 | $853.76 |
| Filing & Storage | 4 | 123 | $742.27 |
| Notebooks & Pads | 5 | 147 | $709.53 |
| Art & Craft | 4 | 59 | $677.91 |
| Desktop Supplies | 5 | 145 | $611.55 |
| Calculators & Tech | 3 | 24 | $399.76 |

## 🛒 Recent Sales Activity
| Timestamp | Sale ID | Item Name | Qty Sold | Unit Price | Total Price |
| :--- | :--- | :--- | :---: | :---: | :---: |
| 2026-11-18 03:18:10 | SALE-SAMPLE-001 | A5 Spiral Classic Notebook | 5 | $3.49 | $17.45 |
| 2026-11-18 21:18:10 | SALE-SAMPLE-002 | Gel Pen 0.5mm Black (Box of 12) | 2 | $9.99 | $19.98 |
| 2026-11-19 15:18:10 | SALE-SAMPLE-003 | Pastel Aesthetic Highlighters (6-Pack) | 3 | $7.99 | $23.97 |
| 2026-11-20 09:18:10 | SALE-SAMPLE-004 | A4 Multipurpose Copy Paper (500 Sheets) | 10 | $5.49 | $54.90 |
| 2026-11-21 03:18:10 | SALE-SAMPLE-005 | Heavy-Duty Desktop Stapler | 1 | $11.99 | $11.99 |
| 2026-11-21 21:18:10 | SALE-SAMPLE-006 | Acrylic Paint Set (24 Colors) | 2 | $18.99 | $37.98 |
| 2026-11-22 15:18:10 | SALE-SAMPLE-007 | Expanding Accordion File Folder | 4 | $8.49 | $33.96 |
| 2026-11-23 09:18:10 | SALE-SAMPLE-008 | Scientific Financial Calculator | 1 | $19.99 | $19.99 |

---
*Report generated automatically by Stationery Shop Manager Analytics Engine.*