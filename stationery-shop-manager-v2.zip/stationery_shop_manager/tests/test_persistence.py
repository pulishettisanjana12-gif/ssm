import unittest
import sys
import os
import shutil
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from models import Item, Sale
from persistence import FilePersistenceManager

class TestPersistence(unittest.TestCase):
    def setUp(self):
        self.test_dir = os.path.abspath("test_pers_data")
        os.makedirs(self.test_dir, exist_ok=True)
        self.json_items = os.path.join(self.test_dir, "test_items.json")
        self.json_sales = os.path.join(self.test_dir, "test_sales.json")
        self.csv_items = os.path.join(self.test_dir, "test_items.csv")
        self.csv_sales = os.path.join(self.test_dir, "test_sales.csv")

    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_json_save_and_load(self):
        items = [Item("P1", "Paper A4", "Paper", 4.99, 100)]
        sales = [Sale("S1", "P1", "Paper A4", 5, 4.99, 24.95)]

        FilePersistenceManager.save_to_json(items, sales, self.json_items, self.json_sales)
        loaded_items, loaded_sales = FilePersistenceManager.load_from_json(self.json_items, self.json_sales)

        self.assertEqual(len(loaded_items), 1)
        self.assertEqual(loaded_items[0].name, "Paper A4")
        self.assertEqual(len(loaded_sales), 1)
        self.assertEqual(loaded_sales[0].total_price, 24.95)

    def test_csv_save_and_load(self):
        items = [Item("P2", "Stapler", "Desktop", 8.99, 20)]
        sales = [Sale("S2", "P2", "Stapler", 1, 8.99, 8.99)]

        FilePersistenceManager.save_to_csv(items, sales, self.csv_items, self.csv_sales)
        loaded_items, loaded_sales = FilePersistenceManager.load_from_csv(self.csv_items, self.csv_sales)

        self.assertEqual(len(loaded_items), 1)
        self.assertEqual(loaded_items[0].name, "Stapler")
        self.assertEqual(len(loaded_sales), 1)

if __name__ == "__main__":
    unittest.main()
