import os
from datetime import datetime, timedelta
from typing import List, Tuple
from models import Item, Sale
from persistence import FilePersistenceManager
from db_persistence import SQLitePersistenceManager
from logger import logger

SAMPLE_ITEMS = [
    # Notebooks & Pads
    Item("NB-101", "A5 Spiral Classic Notebook", "Notebooks & Pads", 3.49, 120, 20),
    Item("NB-102", "Hardcover Executive Journal", "Notebooks & Pads", 12.99, 15, 10),
    Item("NB-103", "Graph Paper Lab Notebook", "Notebooks & Pads", 5.99, 4, 15), # REORDER NEEDED
    Item("NB-104", "Pocket Memo Pad (3-Pack)", "Notebooks & Pads", 2.99, 0, 10), # OUT OF STOCK
    Item("NB-105", "B5 Dotted Bullet Journal", "Notebooks & Pads", 8.99, 8, 10),  # LOW STOCK

    # Writing Instruments
    Item("PEN-201", "Gel Pen 0.5mm Black (Box of 12)", "Writing Instruments", 9.99, 45, 15),
    Item("PEN-202", "Retractable Ballpoint Blue", "Writing Instruments", 0.99, 300, 50),
    Item("PEN-203", "Fine Point Mechanical Pencil 0.7mm", "Writing Instruments", 2.49, 3, 10), # REORDER NEEDED
    Item("PEN-204", "Calligraphy Fountain Pen Set", "Writing Instruments", 24.99, 12, 5),
    Item("PEN-205", "Erasable Gel Pens (4-Pack)", "Writing Instruments", 6.49, 0, 10), # OUT OF STOCK

    # Markers & Highlighters
    Item("MKR-301", "Pastel Aesthetic Highlighters (6-Pack)", "Markers & Highlighters", 7.99, 55, 15),
    Item("MKR-302", "Dry Erase Board Markers (4-Pack)", "Markers & Highlighters", 4.99, 25, 10),
    Item("MKR-303", "Permanent Dual-Tip Black Markers", "Markers & Highlighters", 3.29, 6, 10), # LOW STOCK
    Item("MKR-304", "Dual Brush Marker Pens (12 Colors)", "Markers & Highlighters", 14.99, 18, 5),

    # Art & Craft
    Item("ART-401", "Acrylic Paint Set (24 Colors)", "Art & Craft", 18.99, 22, 5),
    Item("ART-402", "Watercolor Sketchbook (300gsm)", "Art & Craft", 11.49, 7, 10), # LOW STOCK
    Item("ART-403", "Precision Craft Knife + Blades", "Art & Craft", 5.99, 30, 8),
    Item("ART-404", "Colored Pencils Premium (36 Pack)", "Art & Craft", 15.99, 0, 10), # OUT OF STOCK

    # Filing & Storage
    Item("FL-501", "Expanding Accordion File Folder", "Filing & Storage", 8.49, 40, 10),
    Item("FL-502", "Lever Arch Binder 3-Inch", "Filing & Storage", 6.99, 18, 10),
    Item("FL-503", "Clear Sheet Protectors (100-Pack)", "Filing & Storage", 7.49, 5, 15), # REORDER NEEDED
    Item("FL-504", "Plastic Document Wallets (5-Pack)", "Filing & Storage", 3.99, 60, 20),

    # Desktop Supplies
    Item("DSK-601", "Heavy-Duty Desktop Stapler", "Desktop Supplies", 11.99, 14, 5),
    Item("DSK-602", "Standard Staples Box (5000 Qty)", "Desktop Supplies", 2.49, 85, 20),
    Item("DSK-603", "Self-Adhesive Sticky Notes (12-Pack)", "Desktop Supplies", 6.99, 9, 15), # LOW STOCK
    Item("DSK-604", "Stainless Steel Scissors 8-Inch", "Desktop Supplies", 4.49, 35, 10),
    Item("DSK-605", "Tape Dispenser + 2 Roll Refills", "Desktop Supplies", 5.99, 2, 10), # REORDER NEEDED

    # Calculators & Tech
    Item("TECH-701", "Scientific Financial Calculator", "Calculators & Tech", 19.99, 16, 5),
    Item("TECH-702", "Desktop 12-Digit Large Display", "Calculators & Tech", 9.99, 8, 5),
    Item("TECH-703", "USB Digital Presenter Clicker", "Calculators & Tech", 15.49, 0, 5), # OUT OF STOCK

    # Paper & Envelopes
    Item("PPR-801", "A4 Multipurpose Copy Paper (500 Sheets)", "Paper & Envelopes", 5.49, 210, 30),
    Item("PPR-802", "Self-Seal Security Envelopes (100-Pack)", "Paper & Envelopes", 4.99, 75, 15),
    Item("PPR-803", "Heavyweight Cardstock White (50 Sheets)", "Paper & Envelopes", 7.99, 18, 10),
    Item("PPR-804", "Colored Construction Paper Pack", "Paper & Envelopes", 6.49, 32, 10),
    Item("PPR-805", "Thermal Receipt Paper Rolls (10-Pack)", "Paper & Envelopes", 8.99, 2, 10) # REORDER NEEDED
]

def generate_sample_sales() -> List[Sale]:
    sales = []
    base_time = datetime.now() - timedelta(days=7)
    
    sample_sales_data = [
        ("NB-101", "A5 Spiral Classic Notebook", 5, 3.49),
        ("PEN-201", "Gel Pen 0.5mm Black (Box of 12)", 2, 9.99),
        ("MKR-301", "Pastel Aesthetic Highlighters (6-Pack)", 3, 7.99),
        ("PPR-801", "A4 Multipurpose Copy Paper (500 Sheets)", 10, 5.49),
        ("DSK-601", "Heavy-Duty Desktop Stapler", 1, 11.99),
        ("ART-401", "Acrylic Paint Set (24 Colors)", 2, 18.99),
        ("FL-501", "Expanding Accordion File Folder", 4, 8.49),
        ("TECH-701", "Scientific Financial Calculator", 1, 19.99)
    ]

    for idx, (item_id, item_name, qty, price) in enumerate(sample_sales_data, start=1):
        sale_time = (base_time + timedelta(hours=idx * 18)).strftime("%Y-%m-%d %H:%M:%S")
        total = round(qty * price, 2)
        sales.append(Sale(
            sale_id=f"SALE-SAMPLE-{idx:03d}",
            item_id=item_id,
            item_name=item_name,
            quantity_sold=qty,
            unit_price=price,
            total_price=total,
            timestamp=sale_time
        ))

    return sales

def generate_all_sample_data(target_dir: str = "data") -> Tuple[List[Item], List[Sale]]:
    target_dir = os.path.abspath(target_dir)
    os.makedirs(target_dir, exist_ok=True)

    items = SAMPLE_ITEMS
    sales = generate_sample_sales()

    json_items = os.path.join(target_dir, "inventory.json")
    json_sales = os.path.join(target_dir, "sales.json")
    csv_items = os.path.join(target_dir, "inventory.csv")
    csv_sales = os.path.join(target_dir, "sales.csv")
    db_path = os.path.join(target_dir, "ssm.db")

    FilePersistenceManager.save_to_json(items, sales, json_items, json_sales)
    FilePersistenceManager.save_to_csv(items, sales, csv_items, csv_sales)
    
    db_mgr = SQLitePersistenceManager(db_path)
    db_mgr.save_all(items, sales)

    logger.info(f"Generated 35 sample items and {len(sales)} sample sales in '{target_dir}'.")
    return items, sales

if __name__ == "__main__":
    generate_all_sample_data("data")
    print("Sample datasets (JSON, CSV, SQLite) successfully seeded!")
