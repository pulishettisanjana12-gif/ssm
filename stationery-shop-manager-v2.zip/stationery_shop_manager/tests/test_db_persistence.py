import unittest
import sys
import os
import shutil
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from models import Item, Sale
from db_persistence import SQLitePersistenceManager

class TestDBPersistence(unittest.TestCase):
    def setUp(self):
        self.test_dir = os.path.abspath("test_db_data")
        os.makedirs(self.test_dir, exist_ok=True)
        self.db_path = os.path.join(self.test_dir, "test_ssm.db")
        self.db_mgr = SQLitePersistenceManager(self.db_path)

    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_sqlite_save_and_load(self):
        items = [Item("DB-1", "Database Book", "Notebooks", 15.00, 30)]
        sales = [Sale("DB-SALE-1", "DB-1", "Database Book", 2, 15.00, 30.00)]

        self.db_mgr.save_all(items, sales)
        loaded_items, loaded_sales = self.db_mgr.load_all()

        self.assertEqual(len(loaded_items), 1)
        self.assertEqual(loaded_items[0].item_id, "DB-1")
        self.assertEqual(loaded_items[0].unit_price, 15.00)

        self.assertEqual(len(loaded_sales), 1)
        self.assertEqual(loaded_sales[0].sale_id, "DB-SALE-1")

if __name__ == "__main__":
    unittest.main()
