import sqlite3
import os
from typing import List, Tuple, Dict, Any
from models import Item, Sale
from logger import logger

class DBPersistenceError(Exception):
    """Custom exception for database operation failures."""
    pass

class SQLitePersistenceManager:
    """Disk-backed SQLite persistence engine for inventory management and sales records."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.Error as e:
            logger.error(f"Failed to connect to SQLite DB at {self.db_path}: {e}")
            raise DBPersistenceError(f"Database connection error: {e}")

    def _init_db(self) -> None:
        """Initializes database schema if tables do not exist."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS items (
                        item_id TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        category TEXT NOT NULL,
                        unit_price REAL NOT NULL,
                        quantity INTEGER NOT NULL,
                        reorder_threshold INTEGER NOT NULL DEFAULT 10,
                        last_restocked TEXT NOT NULL
                    );
                """)
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS sales (
                        sale_id TEXT PRIMARY KEY,
                        item_id TEXT NOT NULL,
                        item_name TEXT NOT NULL,
                        quantity_sold INTEGER NOT NULL,
                        unit_price REAL NOT NULL,
                        total_price REAL NOT NULL,
                        timestamp TEXT NOT NULL,
                        FOREIGN KEY (item_id) REFERENCES items (item_id)
                    );
                """)
                conn.commit()
                logger.info(f"SQLite schema initialized at {self.db_path}.")
        except sqlite3.Error as e:
            logger.error(f"Failed to initialize SQLite schema: {e}")
            raise DBPersistenceError(f"Schema initialization error: {e}")

    def save_all(self, items: List[Item], sales: List[Sale]) -> None:
        """Saves or updates all items and sales records atomically in SQLite."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                # Clear and insert items to mirror current state atomically
                cursor.execute("DELETE FROM items;")
                cursor.executemany("""
                    INSERT INTO items (item_id, name, category, unit_price, quantity, reorder_threshold, last_restocked)
                    VALUES (:item_id, :name, :category, :unit_price, :quantity, :reorder_threshold, :last_restocked);
                """, [item.to_dict() for item in items])

                cursor.execute("DELETE FROM sales;")
                cursor.executemany("""
                    INSERT INTO sales (sale_id, item_id, item_name, quantity_sold, unit_price, total_price, timestamp)
                    VALUES (:sale_id, :item_id, :item_name, :quantity_sold, :unit_price, :total_price, :timestamp);
                """, [sale.to_dict() for sale in sales])

                conn.commit()
                logger.info(f"SQLite DB sync complete: {len(items)} items, {len(sales)} sales saved.")
        except sqlite3.Error as e:
            logger.error(f"Failed to save data to SQLite DB: {e}")
            raise DBPersistenceError(f"Database save transaction failed: {e}")

    def load_all(self) -> Tuple[List[Item], List[Sale]]:
        """Loads items and sales records from SQLite DB."""
        items: List[Item] = []
        sales: List[Sale] = []

        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM items;")
                item_rows = cursor.fetchall()
                for row in item_rows:
                    items.append(Item.from_dict(dict(row)))

                cursor.execute("SELECT * FROM sales ORDER BY timestamp DESC;")
                sale_rows = cursor.fetchall()
                for row in sale_rows:
                    sales.append(Sale.from_dict(dict(row)))

                logger.info(f"Loaded {len(items)} items and {len(sales)} sales from SQLite DB.")
                return items, sales
        except sqlite3.Error as e:
            logger.error(f"Failed to load data from SQLite DB: {e}")
            raise DBPersistenceError(f"Database load transaction failed: {e}")
