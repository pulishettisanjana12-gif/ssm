import unittest
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from validator import (
    validate_string, validate_positive_int, validate_positive_float,
    validate_item_id, validate_category, ValidationError
)

class TestValidator(unittest.TestCase):
    def test_validate_string(self):
        self.assertEqual(validate_string("  Pencil  ", "Name"), "Pencil")
        with self.assertRaises(ValidationError):
            validate_string("", "Name")
        with self.assertRaises(ValidationError):
            validate_string("A" * 105, "Name", max_len=100)

    def test_validate_positive_int(self):
        self.assertEqual(validate_positive_int("15", "Qty"), 15)
        self.assertEqual(validate_positive_int(0, "Qty", allow_zero=True), 0)
        with self.assertRaises(ValidationError):
            validate_positive_int(-5, "Qty")
        with self.assertRaises(ValidationError):
            validate_positive_int("abc", "Qty")

    def test_validate_positive_float(self):
        self.assertEqual(validate_positive_float("12.50", "Price"), 12.50)
        with self.assertRaises(ValidationError):
            validate_positive_float(-1.99, "Price")

    def test_validate_item_id(self):
        self.assertEqual(validate_item_id("nb-101"), "NB-101")
        with self.assertRaises(ValidationError):
            validate_item_id("NB 101!") # invalid spaces and special chars

    def test_validate_category(self):
        self.assertEqual(validate_category("notebooks & pads"), "Notebooks & Pads")
        self.assertEqual(validate_category("Custom Art"), "Custom Art")

if __name__ == "__main__":
    unittest.main()
