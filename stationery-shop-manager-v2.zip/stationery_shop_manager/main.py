import os
import sys
from typing import Optional
from logger import logger, LOG_FILE
from models import Item
from inventory import InventoryManager
from analytics import AnalyticsEngine
from visualizer import VisualAnalyticsEngine
from validator import ValidationError, VALID_CATEGORIES
from sample_generator import generate_all_sample_data
from run_tests import run_all_tests

def clear_screen():
    print("\n" + "-" * 70 + "\n")

def print_header(title: str):
    print("=" * 70)
    print(f"  📌 STATIONERY SHOP MANAGER (SSM) v2.0 - {title.upper()}")
    print("=" * 70)

def display_items_table(items):
    if not items:
        print("  [!] No stationery items found matching criteria.")
        return

    print(f"{'ID':<10} | {'Name':<28} | {'Category':<20} | {'Price ($)':<9} | {'Qty':<5} | {'Status':<15}")
    print("-" * 98)

    for item in items:
        status_color = item.stock_status
        if item.stock_status == "IN STOCK":
            status_symbol = "✅ IN STOCK"
        elif item.stock_status == "LOW STOCK":
            status_symbol = "🟡 LOW STOCK"
        elif item.stock_status == "REORDER NEEDED":
            status_symbol = "🟠 REORDER NEEDED"
        else:
            status_symbol = "🔴 OUT OF STOCK"

        name_trunc = item.name[:27] + "…" if len(item.name) > 28 else item.name
        cat_trunc = item.category[:19] + "…" if len(item.category) > 20 else item.category

        print(f"{item.item_id:<10} | {name_trunc:<28} | {cat_trunc:<20} | ${item.unit_price:<8.2f} | {item.quantity:<5} | {status_symbol:<15}")

    print("-" * 98)

def print_startup_alerts(inventory_mgr: InventoryManager):
    items = inventory_mgr.get_all_items()
    critical = [i for i in items if i.stock_status in ["REORDER NEEDED", "OUT OF STOCK"]]
    low = [i for i in items if i.stock_status == "LOW STOCK"]

    if critical or low:
        print("\n  ⚠️  STARTUP INVENTORY HEALTH ALERT:")
        if critical:
            print(f"  🔴 CRITICAL STOCK ALERTS: {len(critical)} item(s) require immediate reordering or are out of stock.")
        if low:
            print(f"  🟡 LOW STOCK WARNING: {len(low)} item(s) are approaching threshold.")
        print("  💡 Select Option 1 or 5 to inspect affected inventory items.\n")

def main():
    logger.info("Starting Stationery Shop Manager Application (v2.0)...")
    inventory_mgr = InventoryManager(data_dir="data", storage_mode="sqlite")

    # If database empty, seed sample data automatically
    if not inventory_mgr.get_all_items():
        print("\n  📦 Seeding initial 35 sample stationery items across 8 categories...")
        generate_all_sample_data("data")
        inventory_mgr.load_data()

    print_header("Executive Inventory Dashboard")
    print_startup_alerts(inventory_mgr)

    while True:
        print("\n" + "=" * 70)
        print("                        MAIN MENU")
        print("=" * 70)
        print("  1.  📋 View Inventory Catalog & Alerts")
        print("  2.  ➕ Add New Stationery Item")
        print("  3.  🔄 Update Item Metadata / Restock Quantity")
        print("  4.  🛒 Record Customer Purchase / Sale")
        print("  5.  🔍 Search & Filter Inventory (By Keyword, Category, Status)")
        print("  6.  🗑️  Delete Stationery Item")
        print("  7.  📊 Generate Executive Analytics & Markdown Report")
        print("  8.  🎨 Export Matplotlib Visual Charts & Analytics Dashboard")
        print("  9.  ⚙️  Storage & Database Settings (JSON / CSV / SQLite Sync)")
        print("  10. 🧪 Run Automated Unit Test Suite (100% Coverage)")
        print("  11. 📜 View System Activity Log (ssm.log)")
        print("  12. 🔄 Reset / Reseed 35 Sample Stationery Items")
        print("  0.  🚪 Exit System")
        print("=" * 70)

        choice = input("Enter choice (0-12): ").strip()

        if choice == "1":
            print_header("Inventory Catalog")
            items = inventory_mgr.get_all_items()
            display_items_table(items)

        elif choice == "2":
            print_header("Add New Stationery Item")
            try:
                item_id = input("Enter Item ID (e.g. NB-106): ").strip()
                name = input("Enter Item Name: ").strip()
                
                print("\nAvailable Categories:")
                for idx, cat in enumerate(VALID_CATEGORIES, start=1):
                    print(f"  {idx}. {cat}")
                cat_input = input("Select category number or type custom name: ").strip()
                if cat_input.isdigit() and 1 <= int(cat_input) <= len(VALID_CATEGORIES):
                    category = VALID_CATEGORIES[int(cat_input) - 1]
                else:
                    category = cat_input

                price_str = input("Enter Unit Price ($): ").strip()
                qty_str = input("Enter Quantity in Stock: ").strip()
                thresh_str = input("Enter Reorder Threshold (Default 10): ").strip() or "10"

                new_item = inventory_mgr.add_item(
                    item_id=item_id,
                    name=name,
                    category=category,
                    unit_price=float(price_str),
                    quantity=int(qty_str),
                    reorder_threshold=int(thresh_str)
                )
                print(f"\n  ✅ Successfully added '{new_item.name}' (ID: {new_item.item_id}) to inventory.")
            except ValidationError as e:
                print(f"\n  ❌ Validation Error: {e}")
            except Exception as e:
                print(f"\n  ❌ System Error: {e}")

        elif choice == "3":
            print_header("Update / Restock Item")
            item_id = input("Enter Item ID to update: ").strip()
            item = inventory_mgr.items.get(item_id.upper())
            if not item:
                print(f"  ❌ Item ID '{item_id}' not found.")
                continue

            print(f"  Selected Item: {item.name} | Current Qty: {item.quantity} | Price: ${item.unit_price:.2f}")
            sub_action = input("Choose action -> (1) Restock Quantity, (2) Edit Price/Details: ").strip()

            try:
                if sub_action == "1":
                    add_qty = input("Enter additional stock quantity to add: ").strip()
                    updated = inventory_mgr.restock_item(item_id, int(add_qty))
                    print(f"\n  ✅ Restocked '{updated.name}'. New Total Quantity: {updated.quantity}")
                elif sub_action == "2":
                    new_name = input(f"New Name (Leave blank to keep '{item.name}'): ").strip() or None
                    new_price = input(f"New Unit Price (Leave blank to keep '${item.unit_price:.2f}'): ").strip()
                    new_price_val = float(new_price) if new_price else None
                    new_thresh = input(f"New Threshold (Leave blank to keep '{item.reorder_threshold}'): ").strip()
                    new_thresh_val = int(new_thresh) if new_thresh else None

                    updated = inventory_mgr.update_item(
                        item_id, name=new_name, unit_price=new_price_val, reorder_threshold=new_thresh_val
                    )
                    print(f"\n  ✅ Updated item details for '{updated.name}'.")
            except ValidationError as e:
                print(f"\n  ❌ Validation Error: {e}")

        elif choice == "4":
            print_header("Record Customer Purchase")
            item_id = input("Enter Item ID purchased: ").strip()
            qty_sold_str = input("Enter Quantity Sold: ").strip()

            try:
                sale = inventory_mgr.record_sale(item_id, int(qty_sold_str))
                print(f"\n  🛒 SALE RECORDED SUCCESSFULLY!")
                print(f"  Transaction ID: {sale.sale_id}")
                print(f"  Item: {sale.item_name} x {sale.quantity_sold}")
                print(f"  Total Price: ${sale.total_price:.2f}")
            except ValidationError as e:
                print(f"\n  ❌ Sale Failed: {e}")

        elif choice == "5":
            print_header("Search & Filter Inventory")
            query = input("Enter search keyword (name/ID) or leave blank: ").strip() or None
            
            print("\nFilter by Stock Alert:")
            print("  1. All Items | 2. IN STOCK | 3. LOW STOCK | 4. REORDER NEEDED | 5. OUT OF STOCK")
            st_choice = input("Select option (1-5): ").strip()
            status_map = {"1": "ALL", "2": "IN STOCK", "3": "LOW STOCK", "4": "REORDER NEEDED", "5": "OUT OF STOCK"}
            selected_status = status_map.get(st_choice, "ALL")

            results = inventory_mgr.search_items(query=query, stock_status=selected_status)
            print(f"\nFound {len(results)} matching item(s):\n")
            display_items_table(results)

        elif choice == "6":
            print_header("Delete Stationery Item")
            item_id = input("Enter Item ID to delete: ").strip()
            confirm = input(f"Are you sure you want to delete '{item_id}'? (y/n): ").strip().lower()
            if confirm == "y":
                try:
                    deleted = inventory_mgr.delete_item(item_id)
                    print(f"\n  ✅ Item '{deleted.name}' deleted successfully.")
                except ValidationError as e:
                    print(f"\n  ❌ Error: {e}")

        elif choice == "7":
            print_header("Executive Analytics & Summary Report")
            items = inventory_mgr.get_all_items()
            sales = inventory_mgr.get_all_sales()
            metrics = AnalyticsEngine.get_summary_metrics(items, sales)

            print(f"  📈 Total Catalog Items: {metrics['total_items']}")
            print(f"  📦 Total Stock Quantity: {metrics['total_units']} units")
            print(f"  💰 Total Inventory Valuation: ${metrics['total_valuation']:,.2f}")
            print(f"  💵 Total Sales Revenue: ${metrics['total_revenue']:,.2f} ({metrics['total_sales_count']} sales)")
            print("\n  Stock Health Summary:")
            for status, count in metrics["status_counts"].items():
                print(f"    - {status}: {count}")

            report_path = "reports/summary_report.md"
            AnalyticsEngine.export_markdown_report(items, sales, report_path)
            print(f"\n  📄 Full Markdown Executive Summary Report exported to '{report_path}'.")

        elif choice == "8":
            print_header("Matplotlib Visual Charts")
            items = inventory_mgr.get_all_items()
            print("  🎨 Generating visual charts using Matplotlib engine...")
            saved_charts = VisualAnalyticsEngine.generate_all_charts(items, "reports/charts")

            if saved_charts:
                print("\n  ✅ Successfully exported visual analytics charts to 'reports/charts/':")
                for chart in saved_charts:
                    print(f"    - 📊 {chart}")
            else:
                print("\n  ⚠️ Could not generate charts (Matplotlib not available).")

        elif choice == "9":
            print_header("Storage & Persistence Settings")
            print(f"  Current Active Storage Backend: [{inventory_mgr.storage_mode.upper()}]")
            print("  Available Storage Backends:")
            print("    1. SQLite Database (Disk-backed relational database - Recommended)")
            print("    2. JSON Files (data/inventory.json)")
            print("    3. CSV Files (data/inventory.csv)")
            
            new_mode = input("Select backend choice (1-3): ").strip()
            mode_map = {"1": "sqlite", "2": "json", "3": "csv"}
            if new_mode in mode_map:
                inventory_mgr.set_storage_mode(mode_map[new_mode])
                print(f"\n  ✅ Storage backend switched to [{inventory_mgr.storage_mode.upper()}] successfully.")

        elif choice == "10":
            print_header("Automated Unit Test Suite")
            run_all_tests()

        elif choice == "11":
            print_header("System Activity Log (ssm.log)")
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                print(f"  Showing last 20 log entries from '{LOG_FILE}':\n")
                for line in lines[-20:]:
                    print("  " + line.strip())
            else:
                print("  [!] No log file found yet.")

        elif choice == "12":
            print_header("Reset / Seed Sample Data")
            confirm = input("Are you sure you want to reset and reseed 35 sample stationery items? (y/n): ").strip().lower()
            if confirm == "y":
                generate_all_sample_data("data")
                inventory_mgr.load_data()
                print("\n  ✅ Inventory successfully reseeded with 35 realistic stationery items.")

        elif choice == "0":
            print("\n  👋 Exiting Stationery Shop Manager. Thank you!\n")
            sys.exit(0)

        else:
            print("  ❌ Invalid option. Please select 0-12.")

if __name__ == "__main__":
    main()
