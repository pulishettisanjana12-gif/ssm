import re
from typing import Optional, List, Any
from logger import logger

VALID_CATEGORIES = [
    "Notebooks & Pads",
    "Writing Instruments",
    "Markers & Highlighters",
    "Art & Craft",
    "Filing & Storage",
    "Desktop Supplies",
    "Calculators & Tech",
    "Paper & Envelopes"
]

class ValidationError(Exception):
    """Custom exception raised when validation fails."""
    pass

def validate_string(val: str, name: str, min_len: int = 1, max_len: int = 100) -> str:
    if not isinstance(val, str):
        logger.warning(f"Validation failed: {name} must be a string.")
        raise ValidationError(f"'{name}' must be a valid text string.")
    cleaned = val.strip()
    if len(cleaned) < min_len:
        logger.warning(f"Validation failed: {name} length below minimum ({min_len}).")
        raise ValidationError(f"'{name}' cannot be empty or shorter than {min_len} characters.")
    if len(cleaned) > max_len:
        logger.warning(f"Validation failed: {name} length exceeds maximum ({max_len}).")
        raise ValidationError(f"'{name}' cannot exceed {max_len} characters.")
    return cleaned

def validate_positive_int(val: Any, name: str, allow_zero: bool = False) -> int:
    try:
        num = int(val)
    except (ValueError, TypeError):
        logger.warning(f"Validation failed: {name} could not be converted to int. Input: {val}")
        raise ValidationError(f"'{name}' must be a valid whole number.")
    
    if allow_zero and num < 0:
        raise ValidationError(f"'{name}' cannot be negative.")
    elif not allow_zero and num <= 0:
        raise ValidationError(f"'{name}' must be greater than zero.")
    return num

def validate_positive_float(val: Any, name: str, allow_zero: bool = False) -> float:
    try:
        num = float(val)
    except (ValueError, TypeError):
        logger.warning(f"Validation failed: {name} could not be converted to float. Input: {val}")
        raise ValidationError(f"'{name}' must be a valid number.")
    
    if allow_zero and num < 0.0:
        raise ValidationError(f"'{name}' cannot be negative.")
    elif not allow_zero and num <= 0.0:
        raise ValidationError(f"'{name}' must be greater than zero.")
    return round(num, 2)

def validate_item_id(val: str) -> str:
    cleaned = validate_string(val, "Item ID", min_len=2, max_len=20).upper()
    if not re.match(r"^[A-Z0-9\-_]+$", cleaned):
        logger.warning(f"Validation failed: Invalid Item ID format '{cleaned}'.")
        raise ValidationError("Item ID can only contain letters, numbers, hyphens, and underscores.")
    return cleaned

def validate_category(val: str, custom_categories: Optional[List[str]] = None) -> str:
    cleaned = validate_string(val, "Category", min_len=2)
    categories = custom_categories if custom_categories else VALID_CATEGORIES
    
    # Direct match or case-insensitive match
    for cat in categories:
        if cat.lower() == cleaned.lower():
            return cat
    return cleaned.title()
