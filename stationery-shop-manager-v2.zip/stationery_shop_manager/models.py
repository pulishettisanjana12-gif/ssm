from dataclasses import dataclass, asdict, field
from datetime import datetime
from typing import Dict, Any

@dataclass
class Item:
    item_id: str
    name: str
    category: str
    unit_price: float
    quantity: int
    reorder_threshold: int = 10
    last_restocked: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    @property
    def stock_status(self) -> str:
        """Determines automated inventory alert status."""
        if self.quantity == 0:
            return "OUT OF STOCK"
        elif self.quantity <= (self.reorder_threshold // 2):
            return "REORDER NEEDED"
        elif self.quantity <= self.reorder_threshold:
            return "LOW STOCK"
        return "IN STOCK"

    @property
    def total_value(self) -> float:
        """Calculates total inventory valuation for this item."""
        return round(self.unit_price * self.quantity, 2)

    def to_dict(self) -> Dict[str, Any]:
        """Converts item to a dictionary for serialization."""
        d = asdict(self)
        d["stock_status"] = self.stock_status
        d["total_value"] = self.total_value
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Item":
        """Instantiates an Item object from a dictionary."""
        return cls(
            item_id=str(data["item_id"]).strip(),
            name=str(data["name"]).strip(),
            category=str(data["category"]).strip(),
            unit_price=float(data["unit_price"]),
            quantity=int(data["quantity"]),
            reorder_threshold=int(data.get("reorder_threshold", 10)),
            last_restocked=str(data.get("last_restocked", datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        )


@dataclass
class Sale:
    sale_id: str
    item_id: str
    item_name: str
    quantity_sold: int
    unit_price: float
    total_price: float
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Sale":
        return cls(
            sale_id=str(data["sale_id"]).strip(),
            item_id=str(data["item_id"]).strip(),
            item_name=str(data["item_name"]).strip(),
            quantity_sold=int(data["quantity_sold"]),
            unit_price=float(data["unit_price"]),
            total_price=float(data["total_price"]),
            timestamp=str(data.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        )
