import unittest
import sys
import os
import shutil
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from inventory import InventoryManager
from validator import ValidationError

class TestInventoryManager(unittest.TestCase):
    def setUp(self):
        self.test_dir = os.path.abspath("test_temp_data")
        os.makedirs(self.test_dir, exist_ok=True)
        self.inv = InventoryManager(data_dir=self.test_dir, storage_mode="json")
        self.inv.items.clear()
        self.inv.sales.clear()

    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_add_item(self):
        item = self.inv.add_item("TEST-1", "Test Gel Pen", "Writing Instruments", 1.99, 50)
        self.assertEqual(item.item_id, "TEST-1")
        self.assertIn("TEST-1", self.inv.items)

        # Duplicate ID check
        with self.assertRaises(ValidationError):
            self.inv.add_item("TEST-1", "Duplicate Pen", "Writing Instruments", 1.99, 10)

    def test_record_sale(self):
        self.inv.add_item("TEST-1", "Test Gel Pen", "Writing Instruments", 2.00, 10)
        sale = self.inv.record_sale("TEST-1", 3)
        self.assertEqual(sale.total_price, 6.00)
        self.assertEqual(self.inv.items["TEST-1"].quantity, 7)

        # Insufficient stock sale check
        with self.assertRaises(ValidationError):
            self.inv.record_sale("TEST-1", 20)

    def test_restock_item(self):
        self.inv.add_item("TEST-1", "Test Notebook", "Notebooks & Pads", 5.00, 5)
        updated = self.inv.restock_item("TEST-1", 15)
        self.assertEqual(updated.quantity, 20)

    def test_delete_item(self):
        self.inv.add_item("TEST-1", "Test Folder", "Filing & Storage", 3.00, 10)
        deleted = self.inv.delete_item("TEST-1")
        self.assertEqual(deleted.name, "Test Folder")
        self.assertNotIn("TEST-1", self.inv.items)

    def test_search_items(self):
        self.inv.add_item("T-1", "Blue Gel Pen", "Writing Instruments", 1.50, 100)
        self.inv.add_item("T-2", "Red Marker", "Markers & Highlighters", 2.50, 2)
        
        results = self.inv.search_items(query="Gel")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].item_id, "T-1")

        low_stock = self.inv.search_items(stock_status="REORDER NEEDED")
        self.assertEqual(len(low_stock), 1)
        self.assertEqual(low_stock[0].item_id, "T-2")

if __name__ == "__main__":
    unittest.main()
