import unittest
import sys
import os

def run_all_tests():
    """Discovers and runs all unit tests in the tests/ directory."""
    start_dir = os.path.join(os.path.dirname(__file__), "tests")
    print("=" * 65)
    print(" 🧪 STATIONERY SHOP MANAGER - AUTOMATED TEST SUITE RUNNER")
    print("=" * 65)
    
    loader = unittest.TestLoader()
    suite = loader.discover(start_dir, pattern="test_*.py")
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 65)
    if result.wasSuccessful():
        print(" ✅ ALL UNIT TESTS PASSED SUCCESSFULLY! (100% SUCCESS RATE)")
    else:
        print(f" ❌ TEST SUITE FAILED: {len(result.failures)} Failures, {len(result.errors)} Errors")
    print("=" * 65)
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
