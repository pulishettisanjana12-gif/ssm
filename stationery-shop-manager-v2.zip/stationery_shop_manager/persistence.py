import json
import csv
import os
from typing import List, Tuple, Dict, Any
from models import Item, Sale
from logger import logger

class PersistenceError(Exception):
    """Custom exception raised for persistence failures."""
    pass

class FilePersistenceManager:
    """Handles file persistence for JSON and CSV storage formats with explicit error handling."""

    @staticmethod
    def save_to_json(items: List[Item], sales: List[Sale], filepath_items: str, filepath_sales: str) -> None:
        try:
            os.makedirs(os.path.dirname(filepath_items), exist_ok=True)
            os.makedirs(os.path.dirname(filepath_sales), exist_ok=True)

            with open(filepath_items, "w", encoding="utf-8") as f:
                json.dump([item.to_dict() for item in items], f, indent=4)

            with open(filepath_sales, "w", encoding="utf-8") as f:
                json.dump([sale.to_dict() for sale in sales], f, indent=4)

            logger.info(f"Saved {len(items)} items and {len(sales)} sales to JSON files.")
        except (PermissionError, OSError) as e:
            logger.error(f"Permission or OS error while saving JSON: {e}")
            raise PersistenceError(f"Could not save JSON data: {e}")
        except TypeError as e:
            logger.error(f"Serialization error while encoding JSON: {e}")
            raise PersistenceError(f"Data encoding error: {e}")

    @staticmethod
    def load_from_json(filepath_items: str, filepath_sales: str) -> Tuple[List[Item], List[Sale]]:
        items: List[Item] = []
        sales: List[Sale] = []

        if os.path.exists(filepath_items):
            try:
                with open(filepath_items, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for raw in data:
                        items.append(Item.from_dict(raw))
                logger.info(f"Loaded {len(items)} items from JSON ({filepath_items}).")
            except (json.JSONDecodeError, KeyError, ValueError) as e:
                logger.error(f"Corrupted or invalid JSON in {filepath_items}: {e}")
                raise PersistenceError(f"JSON data in '{filepath_items}' is corrupted or invalid: {e}")
            except (PermissionError, OSError) as e:
                logger.error(f"Failed to access JSON file {filepath_items}: {e}")
                raise PersistenceError(f"File access error for '{filepath_items}': {e}")
        else:
            logger.info(f"JSON file '{filepath_items}' not found. Starting with empty inventory.")

        if os.path.exists(filepath_sales):
            try:
                with open(filepath_sales, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for raw in data:
                        sales.append(Sale.from_dict(raw))
                logger.info(f"Loaded {len(sales)} sales records from JSON ({filepath_sales}).")
            except (json.JSONDecodeError, KeyError, ValueError) as e:
                logger.error(f"Corrupted sales JSON in {filepath_sales}: {e}")
                raise PersistenceError(f"Sales JSON data in '{filepath_sales}' is corrupted: {e}")

        return items, sales

    @staticmethod
    def save_to_csv(items: List[Item], sales: List[Sale], filepath_items: str, filepath_sales: str) -> None:
        try:
            os.makedirs(os.path.dirname(filepath_items), exist_ok=True)
            os.makedirs(os.path.dirname(filepath_sales), exist_ok=True)

            fieldnames = ["item_id", "name", "category", "unit_price", "quantity", "reorder_threshold", "last_restocked"]
            with open(filepath_items, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for item in items:
                    d = item.to_dict()
                    writer.writerow({k: d[k] for k in fieldnames})

            sales_fieldnames = ["sale_id", "item_id", "item_name", "quantity_sold", "unit_price", "total_price", "timestamp"]
            with open(filepath_sales, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=sales_fieldnames)
                writer.writeheader()
                for sale in sales:
                    writer.writerow(sale.to_dict())

            logger.info(f"Saved {len(items)} items and {len(sales)} sales to CSV files.")
        except (PermissionError, OSError, csv.Error) as e:
            logger.error(f"CSV save failed: {e}")
            raise PersistenceError(f"Could not save CSV records: {e}")

    @staticmethod
    def load_from_csv(filepath_items: str, filepath_sales: str) -> Tuple[List[Item], List[Sale]]:
        items: List[Item] = []
        sales: List[Sale] = []

        if os.path.exists(filepath_items):
            try:
                with open(filepath_items, "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        items.append(Item.from_dict(row))
                logger.info(f"Loaded {len(items)} items from CSV ({filepath_items}).")
            except (csv.Error, KeyError, ValueError) as e:
                logger.error(f"CSV read error in {filepath_items}: {e}")
                raise PersistenceError(f"CSV format error in '{filepath_items}': {e}")
            except (PermissionError, OSError) as e:
                logger.error(f"File access error for CSV {filepath_items}: {e}")
                raise PersistenceError(f"Access error for '{filepath_items}': {e}")

        if os.path.exists(filepath_sales):
            try:
                with open(filepath_sales, "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        sales.append(Sale.from_dict(row))
            except (csv.Error, KeyError, ValueError) as e:
                logger.error(f"CSV sales read error: {e}")

        return items, sales
