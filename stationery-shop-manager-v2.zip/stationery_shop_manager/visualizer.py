import os
from typing import List
from models import Item
from analytics import AnalyticsEngine
from logger import logger

try:
    import matplotlib
    matplotlib.use("Agg") # Non-interactive backend
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    logger.warning("Matplotlib is not installed. Visual charting will be disabled.")

class VisualAnalyticsEngine:
    """Generates visual analytics charts and dashboard diagrams using Matplotlib."""

    @staticmethod
    def generate_all_charts(items: List[Item], output_dir: str = "reports/charts") -> List[str]:
        """Generates category, stock status, and valuation charts, returning list of saved file paths."""
        if not MATPLOTLIB_AVAILABLE:
            logger.warning("Matplotlib not available. Skipping chart generation.")
            return []

        os.makedirs(output_dir, exist_ok=True)
        saved_files = []

        chart1 = VisualAnalyticsEngine._plot_category_breakdown(items, os.path.join(output_dir, "category_stock.png"))
        if chart1: saved_files.append(chart1)

        chart2 = VisualAnalyticsEngine._plot_stock_status_donut(items, os.path.join(output_dir, "stock_status.png"))
        if chart2: saved_files.append(chart2)

        chart3 = VisualAnalyticsEngine._plot_category_valuation(items, os.path.join(output_dir, "category_valuation.png"))
        if chart3: saved_files.append(chart3)

        return saved_files

    @staticmethod
    def _plot_category_breakdown(items: List[Item], filepath: str) -> str:
        cat_data = AnalyticsEngine.get_category_breakdown(items)
        if not cat_data:
            return ""

        categories = list(cat_data.keys())
        quantities = [cat_data[c]["total_qty"] for c in categories]

        plt.figure(figsize=(10, 5))
        bars = plt.barh(categories, quantities, color="#4F46E5", edgecolor="#3730A3", linewidth=1.2)
        plt.xlabel("Total Units in Stock", fontsize=11, fontweight="bold", labelpad=8)
        plt.title("Inventory Stock Quantity by Category", fontsize=14, fontweight="bold", pad=12)
        plt.grid(axis="x", linestyle="--", alpha=0.5)

        for bar in bars:
            width = bar.get_width()
            plt.text(width + max(quantities)*0.01, bar.get_y() + bar.get_height()/2, f"{int(width)}",
                     va="center", ha="left", fontsize=9, fontweight="bold", color="#1F2937")

        plt.tight_layout()
        plt.savefig(filepath, dpi=200, bbox_inches="tight")
        plt.close()
        logger.info(f"Generated chart: {filepath}")
        return filepath

    @staticmethod
    def _plot_stock_status_donut(items: List[Item], filepath: str) -> str:
        metrics = AnalyticsEngine.get_summary_metrics(items, [])
        counts = metrics["status_counts"]

        labels = []
        sizes = []
        colors_map = {
            "IN STOCK": "#10B981",
            "LOW STOCK": "#F59E0B",
            "REORDER NEEDED": "#EF4444",
            "OUT OF STOCK": "#6B7280"
        }
        colors = []

        for status, count in counts.items():
            if count > 0:
                labels.append(f"{status} ({count})")
                sizes.append(count)
                colors.append(colors_map.get(status, "#3B82F6"))

        if not sizes:
            return ""

        plt.figure(figsize=(7, 7))
        wedges, texts, autotexts = plt.pie(
            sizes, labels=labels, autopct="%1.1f%%", startangle=140,
            colors=colors, wedgeprops=dict(width=0.4, edgecolor="white", linewidth=2)
        )
        for autotext in autotexts:
            autotext.set_color("white")
            autotext.set_weight("bold")

        plt.title("Inventory Stock Health Distribution", fontsize=14, fontweight="bold", pad=12)
        plt.tight_layout()
        plt.savefig(filepath, dpi=200, bbox_inches="tight")
        plt.close()
        logger.info(f"Generated donut chart: {filepath}")
        return filepath

    @staticmethod
    def _plot_category_valuation(items: List[Item], filepath: str) -> str:
        cat_data = AnalyticsEngine.get_category_breakdown(items)
        if not cat_data:
            return ""

        categories = list(cat_data.keys())
        valuations = [cat_data[c]["valuation"] for c in categories]

        plt.figure(figsize=(10, 5))
        bars = plt.bar(categories, valuations, color="#059669", edgecolor="#047857", linewidth=1.2)
        plt.ylabel("Valuation ($)", fontsize=11, fontweight="bold", labelpad=8)
        plt.title("Total Stock Valuation by Category ($)", fontsize=14, fontweight="bold", pad=12)
        plt.xticks(rotation=30, ha="right", fontsize=9)
        plt.grid(axis="y", linestyle="--", alpha=0.5)

        for bar in bars:
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2, height + max(valuations)*0.01, f"${height:,.0f}",
                     ha="center", va="bottom", fontsize=8, fontweight="bold", color="#111827")

        plt.tight_layout()
        plt.savefig(filepath, dpi=200, bbox_inches="tight")
        plt.close()
        logger.info(f"Generated valuation chart: {filepath}")
        return filepath
