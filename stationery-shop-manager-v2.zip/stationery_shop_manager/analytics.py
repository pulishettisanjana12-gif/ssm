import os
from typing import List, Dict, Any
from datetime import datetime
from models import Item, Sale
from logger import logger

class AnalyticsEngine:
    """Computes executive inventory metrics and generates formatted reports."""

    @staticmethod
    def get_summary_metrics(items: List[Item], sales: List[Sale]) -> Dict[str, Any]:
        total_items = len(items)
        total_units = sum(i.quantity for i in items)
        total_valuation = round(sum(i.total_value for i in items), 2)
        
        status_counts = {
            "IN STOCK": 0,
            "LOW STOCK": 0,
            "REORDER NEEDED": 0,
            "OUT OF STOCK": 0
        }
        for i in items:
            status_counts[i.stock_status] = status_counts.get(i.stock_status, 0) + 1

        total_sales_count = len(sales)
        total_revenue = round(sum(s.total_price for s in sales), 2)
        total_units_sold = sum(s.quantity_sold for s in sales)

        return {
            "total_items": total_items,
            "total_units": total_units,
            "total_valuation": total_valuation,
            "status_counts": status_counts,
            "total_sales_count": total_sales_count,
            "total_revenue": total_revenue,
            "total_units_sold": total_units_sold
        }

    @staticmethod
    def get_category_breakdown(items: List[Item]) -> Dict[str, Dict[str, Any]]:
        categories: Dict[str, Dict[str, Any]] = {}
        for item in items:
            cat = item.category
            if cat not in categories:
                categories[cat] = {"count": 0, "total_qty": 0, "valuation": 0.0}
            categories[cat]["count"] += 1
            categories[cat]["total_qty"] += item.quantity
            categories[cat]["valuation"] += item.total_value

        for cat in categories:
            categories[cat]["valuation"] = round(categories[cat]["valuation"], 2)

        return categories

    @staticmethod
    def export_markdown_report(items: List[Item], sales: List[Sale], filepath: str) -> None:
        """Exports an executive summary report in clean Markdown format."""
        metrics = AnalyticsEngine.get_summary_metrics(items, sales)
        cat_breakdown = AnalyticsEngine.get_category_breakdown(items)
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        lines = [
            "# 📊 Stationery Shop Manager - Executive Summary Report",
            f"**Generated On:** {now_str}",
            "",
            "## 📈 Key Performance Indicators (KPIs)",
            f"- **Total Catalog Items:** {metrics['total_items']}",
            f"- **Total Units in Stock:** {metrics['total_units']} units",
            f"- **Total Inventory Valuation:** ${metrics['total_valuation']:,.2f}",
            f"- **Total Revenue Generated:** ${metrics['total_revenue']:,.2f}",
            f"- **Total Sales Transactions:** {metrics['total_sales_count']}",
            f"- **Total Units Sold:** {metrics['total_units_sold']}",
            "",
            "## ⚠️ Inventory Health & Threshold Breakdown",
            f"- ✅ **In Stock:** {metrics['status_counts']['IN STOCK']}",
            f"- 🟡 **Low Stock Alert:** {metrics['status_counts']['LOW STOCK']}",
            f"- 🟠 **Reorder Needed (Urgent):** {metrics['status_counts']['REORDER NEEDED']}",
            f"- 🔴 **Out of Stock:** {metrics['status_counts']['OUT OF STOCK']}",
            "",
            "## 📁 Inventory Valuation by Category",
            "| Category | Unique Items | Units in Stock | Category Valuation ($) |",
            "| :--- | :---: | :---: | :---: |"
        ]

        for cat, data in sorted(cat_breakdown.items(), key=lambda x: x[1]["valuation"], reverse=True):
            lines.append(f"| {cat} | {data['count']} | {data['total_qty']} | ${data['valuation']:,.2f} |")

        lines.extend([
            "",
            "## 🛒 Recent Sales Activity",
            "| Timestamp | Sale ID | Item Name | Qty Sold | Unit Price | Total Price |",
            "| :--- | :--- | :--- | :---: | :---: | :---: |"
        ])

        recent_sales = sales[-10:] if len(sales) > 10 else sales
        if not recent_sales:
            lines.append("| - | No sales recorded yet. | - | - | - | - |")
        else:
            for s in reversed(recent_sales):
                lines.append(f"| {s.timestamp} | {s.sale_id} | {s.item_name} | {s.quantity_sold} | ${s.unit_price:.2f} | ${s.total_price:.2f} |")

        lines.append("\n---\n*Report generated automatically by Stationery Shop Manager Analytics Engine.*")

        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        logger.info(f"Exported Markdown summary report to '{filepath}'.")
