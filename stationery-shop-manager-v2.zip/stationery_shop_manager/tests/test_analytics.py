import unittest
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from models import Item, Sale
from analytics import AnalyticsEngine

class TestAnalytics(unittest.TestCase):
    def test_summary_metrics(self):
        items = [
            Item("I1", "Item 1", "Cat A", 10.0, 5, 10),
            Item("I2", "Item 2", "Cat B", 20.0, 0, 5)
        ]
        sales = [
            Sale("S1", "I1", "Item 1", 2, 10.0, 20.0)
        ]

        metrics = AnalyticsEngine.get_summary_metrics(items, sales)
        self.assertEqual(metrics["total_items"], 2)
        self.assertEqual(metrics["total_units"], 5)
        self.assertEqual(metrics["total_valuation"], 50.0)
        self.assertEqual(metrics["total_revenue"], 20.0)
        self.assertEqual(metrics["status_counts"]["OUT OF STOCK"], 1)

    def test_category_breakdown(self):
        items = [
            Item("I1", "Item 1", "Notebooks", 5.0, 10),
            Item("I2", "Item 2", "Notebooks", 10.0, 2)
        ]
        breakdown = AnalyticsEngine.get_category_breakdown(items)
        self.assertIn("Notebooks", breakdown)
        self.assertEqual(breakdown["Notebooks"]["count"], 2)
        self.assertEqual(breakdown["Notebooks"]["total_qty"], 12)
        self.assertEqual(breakdown["Notebooks"]["valuation"], 70.0)

if __name__ == "__main__":
    unittest.main()
