import os
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime
from models import Item, Sale
from validator import (
    validate_item_id, validate_string, validate_category,
    validate_positive_int, validate_positive_float, ValidationError
)
from persistence import FilePersistenceManager, PersistenceError
from db_persistence import SQLitePersistenceManager, DBPersistenceError
from logger import logger

class InventoryManager:
    """Core inventory management controller with dual storage engines (Files & SQLite)."""

    def __init__(self, data_dir: str = "data", storage_mode: str = "json"):
        self.data_dir = os.path.abspath(data_dir)
        os.makedirs(self.data_dir, exist_ok=True)
        
        self.storage_mode = storage_mode.lower() # json, csv, or sqlite
        self.items: Dict[str, Item] = {}
        self.sales: List[Sale] = []
        
        self.json_items_path = os.path.join(self.data_dir, "inventory.json")
        self.json_sales_path = os.path.join(self.data_dir, "sales.json")
        self.csv_items_path = os.path.join(self.data_dir, "inventory.csv")
        self.csv_sales_path = os.path.join(self.data_dir, "sales.csv")
        self.sqlite_db_path = os.path.join(self.data_dir, "ssm.db")

        self.db_manager = SQLitePersistenceManager(self.sqlite_db_path)
        self.load_data()

    def set_storage_mode(self, mode: str) -> None:
        """Switches current storage backend and saves immediately."""
        mode = mode.lower()
        if mode not in ["json", "csv", "sqlite"]:
            raise ValueError("Storage mode must be 'json', 'csv', or 'sqlite'.")
        self.storage_mode = mode
        logger.info(f"Storage backend set to '{self.storage_mode}'.")
        self.save_data()

    def load_data(self) -> None:
        """Loads items and sales using the active storage backend."""
        try:
            if self.storage_mode == "sqlite":
                raw_items, self.sales = self.db_manager.load_all()
            elif self.storage_mode == "csv":
                raw_items, self.sales = FilePersistenceManager.load_from_csv(
                    self.csv_items_path, self.csv_sales_path
                )
            else: # json default
                raw_items, self.sales = FilePersistenceManager.load_from_json(
                    self.json_items_path, self.json_sales_path
                )

            self.items = {item.item_id: item for item in raw_items}
            logger.info(f"Inventory loaded successfully ({len(self.items)} items).")
        except (PersistenceError, DBPersistenceError) as e:
            logger.error(f"Failed to load inventory data: {e}")

    def save_data(self) -> None:
        """Saves current inventory state across all storage modes for redundancy."""
        items_list = list(self.items.values())
        try:
            # Save to active backend
            if self.storage_mode == "sqlite":
                self.db_manager.save_all(items_list, self.sales)
            elif self.storage_mode == "csv":
                FilePersistenceManager.save_to_csv(
                    items_list, self.sales, self.csv_items_path, self.csv_sales_path
                )
            else:
                FilePersistenceManager.save_to_json(
                    items_list, self.sales, self.json_items_path, self.json_sales_path
                )
            
            # Secondary backup to JSON if in other modes
            if self.storage_mode != "json":
                FilePersistenceManager.save_to_json(
                    items_list, self.sales, self.json_items_path, self.json_sales_path
                )
        except (PersistenceError, DBPersistenceError) as e:
            logger.error(f"Save operation failed: {e}")
            raise

    def add_item(self, item_id: str, name: str, category: str, unit_price: float,
                 quantity: int, reorder_threshold: int = 10) -> Item:
        """Adds a new stationery item to inventory after input validation."""
        valid_id = validate_item_id(item_id)
        if valid_id in self.items:
            raise ValidationError(f"Item ID '{valid_id}' already exists in inventory.")

        valid_name = validate_string(name, "Item Name", min_len=2)
        valid_cat = validate_category(category)
        valid_price = validate_positive_float(unit_price, "Unit Price")
        valid_qty = validate_positive_int(quantity, "Quantity", allow_zero=True)
        valid_threshold = validate_positive_int(reorder_threshold, "Reorder Threshold", allow_zero=True)

        new_item = Item(
            item_id=valid_id,
            name=valid_name,
            category=valid_cat,
            unit_price=valid_price,
            quantity=valid_qty,
            reorder_threshold=valid_threshold
        )

        self.items[valid_id] = new_item
        self.save_data()
        logger.info(f"Added new item '{valid_name}' (ID: {valid_id}).")
        return new_item

    def update_item(self, item_id: str, name: Optional[str] = None,
                    category: Optional[str] = None, unit_price: Optional[float] = None,
                    reorder_threshold: Optional[int] = None) -> Item:
        """Updates metadata of an existing item."""
        valid_id = validate_item_id(item_id)
        if valid_id not in self.items:
            raise ValidationError(f"Item ID '{valid_id}' not found.")

        item = self.items[valid_id]
        if name:
            item.name = validate_string(name, "Item Name", min_len=2)
        if category:
            item.category = validate_category(category)
        if unit_price is not None:
            item.unit_price = validate_positive_float(unit_price, "Unit Price")
        if reorder_threshold is not None:
            item.reorder_threshold = validate_positive_int(reorder_threshold, "Reorder Threshold", allow_zero=True)

        self.save_data()
        logger.info(f"Updated item details for '{item.name}' (ID: {valid_id}).")
        return item

    def restock_item(self, item_id: str, additional_quantity: int) -> Item:
        """Restocks inventory quantity for an existing item."""
        valid_id = validate_item_id(item_id)
        if valid_id not in self.items:
            raise ValidationError(f"Item ID '{valid_id}' not found.")

        valid_add = validate_positive_int(additional_quantity, "Restock Quantity")
        item = self.items[valid_id]
        item.quantity += valid_add
        item.last_restocked = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        self.save_data()
        logger.info(f"Restocked '{item.name}' (ID: {valid_id}) by +{valid_add}. New qty: {item.quantity}.")
        return item

    def record_sale(self, item_id: str, quantity_sold: int) -> Sale:
        """Records a customer purchase, deducting stock and creating a sales record."""
        valid_id = validate_item_id(item_id)
        if valid_id not in self.items:
            raise ValidationError(f"Item ID '{valid_id}' not found.")

        valid_qty = validate_positive_int(quantity_sold, "Quantity Sold")
        item = self.items[valid_id]

        if item.quantity < valid_qty:
            logger.warning(f"Insufficient stock for sale: Requested {valid_qty}, available {item.quantity}.")
            raise ValidationError(
                f"Insufficient stock for '{item.name}'. Available: {item.quantity}, Requested: {valid_qty}"
            )

        item.quantity -= valid_qty
        total_price = round(item.unit_price * valid_qty, 2)
        sale_id = f"SALE-{datetime.now().strftime('%Y%m%d%H%M%S')}-{len(self.sales)+1}"

        new_sale = Sale(
            sale_id=sale_id,
            item_id=item.item_id,
            item_name=item.name,
            quantity_sold=valid_qty,
            unit_price=item.unit_price,
            total_price=total_price
        )

        self.sales.append(new_sale)
        self.save_data()
        logger.info(f"Recorded sale '{sale_id}' for {valid_qty}x '{item.name}'. Total: ${total_price:.2f}")
        return new_sale

    def delete_item(self, item_id: str) -> Item:
        """Deletes an item from inventory."""
        valid_id = validate_item_id(item_id)
        if valid_id not in self.items:
            raise ValidationError(f"Item ID '{valid_id}' not found.")

        removed_item = self.items.pop(valid_id)
        self.save_data()
        logger.info(f"Deleted item '{removed_item.name}' (ID: {valid_id}).")
        return removed_item

    def search_items(self, query: Optional[str] = None, category: Optional[str] = None,
                     stock_status: Optional[str] = None) -> List[Item]:
        """Filters inventory by keyword, category, or stock status alert."""
        results = list(self.items.values())

        if query:
            q = query.strip().lower()
            results = [
                item for item in results
                if q in item.name.lower() or q in item.item_id.lower() or q in item.category.lower()
            ]

        if category and category.strip() and category.lower() != "all":
            c = category.strip().lower()
            results = [item for item in results if item.category.lower() == c]

        if stock_status and stock_status.strip() and stock_status.lower() != "all":
            s = stock_status.strip().upper()
            results = [item for item in results if item.stock_status == s]

        return results

    def get_all_items(self) -> List[Item]:
        return list(self.items.values())

    def get_all_sales(self) -> List[Sale]:
        return self.sales
