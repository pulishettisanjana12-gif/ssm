import unittest
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from models import Item, Sale

class TestModels(unittest.TestCase):
    def test_item_creation_and_stock_status(self):
        # In stock
        item1 = Item("I1", "Notebook", "Notebooks", 5.0, 50, 10)
        self.assertEqual(item1.stock_status, "IN STOCK")
        self.assertEqual(item1.total_value, 250.0)

        # Low stock
        item2 = Item("I2", "Pen", "Pens", 2.0, 8, 10)
        self.assertEqual(item2.stock_status, "LOW STOCK")

        # Reorder needed
        item3 = Item("I3", "Pencil", "Pens", 1.0, 4, 10)
        self.assertEqual(item3.stock_status, "REORDER NEEDED")

        # Out of stock
        item4 = Item("I4", "Eraser", "Pens", 0.5, 0, 10)
        self.assertEqual(item4.stock_status, "OUT OF STOCK")

    def test_item_serialization(self):
        item = Item("I100", "Highlighter", "Markers", 3.50, 20)
        data = item.to_dict()
        self.assertEqual(data["item_id"], "I100")
        self.assertEqual(data["stock_status"], "IN STOCK")

        reconstructed = Item.from_dict(data)
        self.assertEqual(reconstructed.name, "Highlighter")
        self.assertEqual(reconstructed.unit_price, 3.50)

    def test_sale_serialization(self):
        sale = Sale("S1", "I1", "Notebook", 2, 5.0, 10.0)
        data = sale.to_dict()
        self.assertEqual(data["sale_id"], "S1")
        self.assertEqual(data["total_price"], 10.0)

        reconstructed = Sale.from_dict(data)
        self.assertEqual(reconstructed.item_name, "Notebook")

if __name__ == "__main__":
    unittest.main()
